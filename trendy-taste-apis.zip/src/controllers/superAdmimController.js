const express = require('express');
const asyncHandler = require('express-async-handler');
const jwt = require('jsonwebtoken');


//Login SuperAdmin 

const superAdminLogin  = asyncHandler(async(req,res) => {
    const { userName, password} = req.body;
    try {
        
    } catch (error) {
        
    }
})


//Create Admin

const createAdmin = asyncHandler(async(req,res) => {
    try {
        
    } catch (error) {
        
    }
})  